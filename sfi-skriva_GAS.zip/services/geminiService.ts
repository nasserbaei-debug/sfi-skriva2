
import { GoogleGenAI, Type } from "@google/genai";
import { SfiLevel, TextGenerationResult } from "../types";
import { SFI_PROMPT_GUIDELINES } from "../constants";

export const generateSfiText = async (topic: string, level: SfiLevel): Promise<TextGenerationResult> => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    throw new Error("API Key is missing. Please check your environment configuration.");
  }

  const ai = new GoogleGenAI({ apiKey });
  
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Create an SFI level ${level} text in Swedish about the topic: "${topic}". 
              Ensure the output strictly follows the JSON schema provided in the instructions.`,
    config: {
      systemInstruction: SFI_PROMPT_GUIDELINES,
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          content: { type: Type.STRING },
          vocabulary: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                word: { type: Type.STRING },
                translation: { type: Type.STRING }
              },
              required: ["word", "translation"]
            }
          },
          questions: {
            type: Type.ARRAY,
            items: { type: Type.STRING }
          }
        },
        required: ["title", "content", "vocabulary", "questions"]
      }
    }
  });

  const text = response.text;
  if (!text) {
    throw new Error("Failed to generate content. The model returned an empty response.");
  }

  try {
    return JSON.parse(text) as TextGenerationResult;
  } catch (err) {
    console.error("Failed to parse response:", text);
    throw new Error("Invalid response format from the AI model.");
  }
};
