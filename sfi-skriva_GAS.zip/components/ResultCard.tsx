
import React from 'react';
import { TextGenerationResult, SfiLevel } from '../types';

interface ResultCardProps {
  result: TextGenerationResult;
  level: SfiLevel;
}

const ResultCard: React.FC<ResultCardProps> = ({ result, level }) => {
  // Split content into paragraphs by double newlines or single newlines
  const paragraphs = result.content.split(/\n\s*\n/).filter(p => p.trim() !== '');

  return (
    <div className="bg-white rounded-2xl shadow-xl overflow-hidden border border-slate-100 animate-in fade-in slide-in-from-bottom-4 duration-700 print:shadow-none print:border-0">
      <div className="bg-gradient-to-r from-blue-600 to-indigo-700 p-6 print:bg-none print:text-black">
        <div className="flex justify-between items-center mb-2 print:hidden">
          <span className="bg-white/20 text-white text-xs font-bold px-2 py-1 rounded uppercase tracking-wider">
            SFI Nivå {level}
          </span>
          <button 
            onClick={() => window.print()}
            className="text-white/80 hover:text-white transition-colors"
            title="Skriv ut text"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z" />
            </svg>
          </button>
        </div>
        <h2 className="text-2xl font-bold text-white leading-tight print:text-black print:text-3xl">
          {result.title}
        </h2>
        <div className="hidden print:block text-slate-500 text-sm mt-1">
          SFI Nivå {level}
        </div>
      </div>

      <div className="p-8">
        <div className="prose prose-slate max-w-none">
          {paragraphs.map((paragraph, index) => (
            <p key={index} className="text-lg text-slate-700 leading-relaxed mb-6 last:mb-0">
              {paragraph.trim()}
            </p>
          ))}
        </div>

        <hr className="my-8 border-slate-100 print:border-slate-300" />

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Vocabulary Section */}
          <section className="print:break-inside-avoid">
            <h3 className="text-lg font-bold text-slate-800 mb-4 flex items-center">
              <span className="w-8 h-8 bg-amber-100 text-amber-700 rounded-lg flex items-center justify-center mr-2 text-sm print:hidden">A/Ö</span>
              Ordlista (Vocabulary)
            </h3>
            <ul className="space-y-2">
              {result.vocabulary.map((v, i) => (
                <li key={i} className="flex justify-between items-center py-2 border-b border-slate-50 last:border-0 print:border-slate-200">
                  <span className="font-semibold text-blue-700 print:text-black">{v.word}</span>
                  <span className="text-slate-500 text-sm">{v.translation}</span>
                </li>
              ))}
            </ul>
          </section>

          {/* Questions Section */}
          <section className="print:break-inside-avoid">
            <h3 className="text-lg font-bold text-slate-800 mb-4 flex items-center">
              <span className="w-8 h-8 bg-green-100 text-green-700 rounded-lg flex items-center justify-center mr-2 text-sm print:hidden">?</span>
              Frågor (Questions)
            </h3>
            <div className="space-y-4">
              {result.questions.map((q, i) => (
                <div key={i} className="bg-slate-50 p-4 rounded-xl text-slate-700 text-sm italic border border-slate-100 print:bg-white print:p-2 print:border-0 print:border-l-2 print:border-slate-300">
                  {i + 1}. {q}
                </div>
              ))}
            </div>
          </section>
        </div>
      </div>
    </div>
  );
};

export default ResultCard;
