
import React from 'react';
import { SfiLevel } from '../types';
import { LEVEL_DESCRIPTIONS } from '../constants';

interface LevelSelectorProps {
  currentLevel: SfiLevel;
  onSelect: (level: SfiLevel) => void;
}

const LevelSelector: React.FC<LevelSelectorProps> = ({ currentLevel, onSelect }) => {
  const levels = [SfiLevel.B, SfiLevel.C, SfiLevel.D];

  return (
    <div className="grid grid-cols-3 gap-4">
      {levels.map((level) => (
        <button
          key={level}
          onClick={() => onSelect(level)}
          className={`p-4 rounded-xl border-2 transition-all duration-200 text-center flex flex-col items-center justify-center space-y-1 ${
            currentLevel === level
              ? 'border-blue-500 bg-blue-50 text-blue-700 shadow-md ring-2 ring-blue-500/20'
              : 'border-slate-200 bg-white text-slate-600 hover:border-slate-300 hover:bg-slate-50'
          }`}
        >
          <span className="text-2xl font-bold">Nivå {level}</span>
          <span className="text-xs font-medium opacity-70">
            {level === SfiLevel.B ? 'Nybörjare' : level === SfiLevel.C ? 'Mellan' : 'Avancerad'}
          </span>
        </button>
      ))}
      <div className="col-span-3 mt-2 text-sm text-slate-500 italic text-center">
        {LEVEL_DESCRIPTIONS[currentLevel]}
      </div>
    </div>
  );
};

export default LevelSelector;
